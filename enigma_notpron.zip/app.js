(() => {
  const app = document.getElementById('app');
  // PISTA DA FASE 1: x²-√26569x+26569-361/4=0
  // Enigma escolar: as respostas são verificadas no navegador.
  // Chave que deve estar codificada no QR físico:
  const QR_SECRET = 'SOL-7F29-K';
  // PISTA DA FASE 2: não dê ouvidos a Vincent. Como você sabe, ele é fácil de impressionar.
  // PISTA DA FASE 3: Cês são burros ou o quê? Vão no armário de honrarias e procurem a descrição.
  const KEY = 'enigmo_progress_v1';
  const state = JSON.parse(localStorage.getItem(KEY) || '{"stage":1}');
  const save = () => localStorage.setItem(KEY, JSON.stringify(state));
  const stageFromHash = () => {
    const h = location.hash.replace('#','').replace('/','');
    return ({'':1,'fase1':1,'vincent':2,'fase2':2,'door':3,'fase3':3,'sunflowers':4,'fase4':4,'end':5,'final':5})[h] || 1;
  };
  const go = (stage) => {
    const hashes = {1:'#/',2:'#/vincent',3:'#/door',4:'#/sunflowers',5:'#/end'};
    location.hash = hashes[stage] || '#/';
    render();
  };
  const norm = s => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,'').replace(/[×x*]/g,'x');
  function field(placeholder, buttonText, callback) {
    return `<form class="form" id="answer"><input id="answerInput" autocomplete="off" placeholder="${placeholder}" aria-label="Resposta"> <button>${buttonText}</button><div class="feedback" id="feedback"></div></form>`;
  }
  function render() {
    let requested = stageFromHash();
    let allowed = Math.min(Number(state.stage)||1,5);
    if (requested > allowed) requested = allowed;
    if (requested !== stageFromHash()) {
      const hashes={1:'#/',2:'#/vincent',3:'#/door',4:'#/sunflowers',5:'#/end'};
      history.replaceState(null,'',location.pathname+location.search+hashes[requested]);
    }
    if(requested===1) {
      app.innerHTML = `<p class="small"> </p><img class="image" src="assets/dimensoes.png" alt="AB × CD = FGGA"><p class="dim">x² − √26569x + 26569 − 361/4 = 0</p><p class="dim">não gosto de zeros</p>${field('ABxCD=FGGA','enviar')}<footer></footer>`;
      document.getElementById('answer').onsubmit=e=>{e.preventDefault();if(norm(document.getElementById('answerInput').value)==='91x72=6552'){state.stage=Math.max(state.stage,2);save();go(2)}else document.getElementById('feedback').textContent='não.'};
    } else if(requested===2) {
      app.innerHTML = `<p>De onde viemos? Quem somos? **** **** *****?</p><audio controls loop preload="metadata" style="display:block;margin:20px 0"><source src="assets/audio-distorcido.mp3" type="audio/mpeg"></audio>${field('xxxx-xxxxxxx','enviar')}<p class="small" style="color:#080808">não dê ouvidos a Vincent. Como você sabe, ele é fácil de impressionar.</p>`;
      document.getElementById('answer').onsubmit=e=>{e.preventDefault();if(norm(document.getElementById('answerInput').value)==='paul-gauguin'){state.stage=Math.max(state.stage,3);save();go(3)}else document.getElementById('feedback').textContent='não.'};
    } else if(requested===3) {
      app.innerHTML = `<div class="door-wrap" aria-label="porta"><div class="door"><span class="knob"></span></div></div><p>a chave está num lugar trancado. Aonde habita um ser alado, ele segura o medalhão, pelo qual a escola tem seu crédito. Não segura uma vitória, mas uma honra ao mérito.</p><p class="small" style="color:#080808">Cês são burros ou o quê? Vão no armário de honrarias e procurem a descrição.</p><p><button id="openCamera">abrir câmera</button></p><div id="reader"></div><p id="qrfeedback" class="feedback"></p>`;
      let scanner=null;
      document.getElementById('openCamera').onclick=async()=>{
        const status=document.getElementById('qrfeedback');
        if(!window.Html5Qrcode){status.textContent='leitor indisponível. Verifique a conexão.';return}
        try {
          scanner=new Html5Qrcode('reader');
          await scanner.start({facingMode:'environment'},{fps:10,qrbox:{width:220,height:220}},async text=>{
            if(text.trim()===QR_SECRET){
              try{await scanner.stop()}catch(e){}
              state.stage=Math.max(state.stage,4);save();go(4);
            } else status.textContent='essa não é a chave.';
          },()=>{});
          status.textContent='aponte a câmera para o código.';
        } catch(e){status.textContent='não foi possível abrir a câmera. Use HTTPS e permita o acesso.'}
      };
    } else if(requested===4) {
      app.innerHTML = `<p>Fui criada como um presente, minha cor amarela era a felicidade. Vá pela escola e procure com intensidade, a resposta não é nosso nome. Pois a facilidade seria tamanha. As boas vindas estão prontas.</p><div class="sunflowers">${['C','A','S','A','A','M','A','R','E','L','A',''].map((x,i)=>`<div class="flower">${x||'_'}</div>`).join('')}</div>${field('resposta','enviar')}`;
      document.getElementById('answer').onsubmit=e=>{e.preventDefault();if(norm(document.getElementById('answerInput').value)==='casaamarela'){state.stage=5;save();go(5)}else document.getElementById('feedback').textContent='não.'};
    } else {
      app.innerHTML = `<div style="margin:20vh auto;text-align:center"><p>Parabéns, você chegou!</p><p>(Espero que não)</p><p>Uma realização de: Nicolas Antônio, Yasmin</p></div>`;
    }
  }
  window.addEventListener('hashchange',render);
  render();
})();